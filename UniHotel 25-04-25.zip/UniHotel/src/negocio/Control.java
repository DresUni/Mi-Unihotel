package negocio;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.swing.table.DefaultTableModel;

// Esta clase controla la lógica entre la interfaz gráfica y la base de datos para la tabla "habitacion"
public class Control {
    private final HabitacionDAO datos; // Conecta con la base de datos
    private final Habitacion obj; // Guarda la información de una habitación
    private DefaultTableModel modeloTabla; // Modelo para mostrar las habitaciones en una tabla
    public int registrosMostrados; // Cuenta cuántas habitaciones se muestran

    // Constructor: inicializa las variables
    public Control() {
        this.datos = new HabitacionDAO();
        this.obj = new Habitacion();
        this.registrosMostrados = 0;
    }

    // Método para obtener la lista de habitaciones y mostrarla en una tabla
    public DefaultTableModel listar(String texto) {
        List<Habitacion> lista = new ArrayList<>();
        lista.addAll(datos.listar(texto)); // Busca habitaciones que coincidan con el texto

        String[] titulos = {"ID", "Tipo", "Subtipo", "Temporada"}; // Encabezados de la tabla
        this.modeloTabla = new DefaultTableModel(null, titulos); // Crea el modelo de la tabla

        String[] registro = new String[4]; // Arreglo para guardar los datos de cada fila
        this.registrosMostrados = 0;

        // Recorre la lista de habitaciones y las agrega a la tabla
        for (Habitacion item : lista) {
            registro[0] = Integer.toString(item.getId());
            registro[1] = item.getTipo();
            registro[2] = item.getSubtipo();
            registro[3] = item.getTemporada();
            this.modeloTabla.addRow(registro);
            this.registrosMostrados++;
        }
        return this.modeloTabla; // Devuelve la tabla lista para mostrar
    }

    // Método para insertar una nueva habitación
    public String insertar(String tipo, String subtipo, String temporada) {
        obj.setTipo(tipo);
        obj.setSubtipo(subtipo);
        obj.setTemporada(temporada);

        if (datos.insertar(obj)) {
            return "OK"; // Si se inserta correctamente
        } else {
            return "Error en el registro."; // Si algo falla
        }
    }

    // Método para actualizar los datos de una habitación existente
    public String actualizar(int id, String tipo, String subtipo, String temporada) {
        obj.setId(id);
        obj.setTipo(tipo);
        obj.setSubtipo(subtipo);
        obj.setTemporada(temporada);

        if (datos.actualizar(obj)) {
            return "OK"; // Si se actualiza correctamente
        } else {
            return "Error en la actualización."; // Si algo falla
        }
    }

    // Método para eliminar una habitación
    public String eliminar(int id) {
        if (datos.eliminar(id)) {
            return "OK"; // Si se elimina correctamente
        } else {
            return "No se pudo eliminar la habitación."; // Si algo falla
        }
    }

    // Devuelve la cantidad total de habitaciones en la base de datos
    public int total() {
        return datos.total();
    }

    // Devuelve la cantidad de habitaciones que se mostraron en la tabla
    public int totalMostrados() {
        return this.registrosMostrados;
    }

    private static class HabitacionDAO {

        public HabitacionDAO() {
        }

        private int total() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private boolean eliminar(int id) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private boolean actualizar(Habitacion obj) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private boolean insertar(Habitacion obj) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private Collection<? extends Habitacion> listar(String texto) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }
    }

    private static class Habitacion {

        public Habitacion() {
        }

        private void setTemporada(String temporada) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private void setTipo(String tipo) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private void setId(int id) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private void setSubtipo(String subtipo) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private String getTemporada() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private String getTipo() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private String getSubtipo() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private int getId() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }
    }
}