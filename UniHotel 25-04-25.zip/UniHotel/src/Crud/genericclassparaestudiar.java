/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Crud;

/**
 *
 Generar las instancias de 
 public class CategoriaDAO implements CrudSimpleInterface<Categoria> {
    private final Conexion CON;
    private PreparedStatement ps;
    private ResultSet rs;
    private boolean resp;
    
    public CategoriaDAO(){
        CON=Conexion.getInstancia();
    }
    
    * 
    * 
    * pack
 */
public class genericclassparaestudiar {
    
}
